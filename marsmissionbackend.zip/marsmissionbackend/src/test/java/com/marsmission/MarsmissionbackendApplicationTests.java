package com.marsmission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarsmissionbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
