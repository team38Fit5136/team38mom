package com.marsmission.team38;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MomUserModelMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MomUserModelMsApplication.class, args);
	}

}
