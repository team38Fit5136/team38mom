package com.marsmission.team38;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MomMissionModelMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
