package com.marsmission.team38;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MomMissionModelMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MomMissionModelMsApplication.class, args);
	}

}
